import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RegisterData extends StatefulWidget {
  @override
  _RegisterDataState createState() => new _RegisterDataState();
}

class _RegisterDataState extends State<RegisterData> {

  TextEditingController controllerName = new TextEditingController();
  TextEditingController controllerStock = new TextEditingController();

  void registerData(){
    var url="http://192.168.43.34/logindata/createdata.php";

    http.post(url, body: {

      "username": controllerName.text,
      "password": controllerStock.text
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Register"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(
          children: <Widget>[
            new Column(
              children: <Widget>[
                new TextField(
                  controller: controllerName,
                  decoration: new InputDecoration(
                      hintText: "username", labelText: "Name"),
                ),
                new TextField(
                  controller: controllerStock,
                  decoration: new InputDecoration(
                      hintText: "password", labelText: "Password"),
                ),
                new Padding(
                  padding: const EdgeInsets.all(10.0),
                ),
                new RaisedButton(
                  child: new Text("Creat"),
                  color: Colors.blueAccent,
                  onPressed: () {
                    registerData();
                    Navigator.pop(context);
                  },
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
