<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "users";

    $connect = new mysqli($host, $user, $pass, $db);

    if($connect){
    
    } else {
        echo "gagal";
        exit();
    }

?>